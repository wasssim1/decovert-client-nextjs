import React from "react";
import RegistrationForm from "@/form/register-form";

const RegistarMain = () => {
  return (
    <>
      <RegistrationForm />
    </>
  );
};

export default RegistarMain;
