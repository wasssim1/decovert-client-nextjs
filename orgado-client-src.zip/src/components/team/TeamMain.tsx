import React from 'react';
import TeamSectionSingle from './TeamSectionSingle';

const TeamMain = () => {
    return (
        <>
            <TeamSectionSingle/>
        </>
    );
};

export default TeamMain;