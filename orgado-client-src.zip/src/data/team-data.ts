export interface TeamMember {
    id: number;
    teamImg: string;
    teamSubtitle: string;
    teamTitle: string;
  }

const TeamList:TeamMember[] = [
    {
        id:1,
        teamImg:'/assets/img/team/team-thumb-01.jpg',
        teamSubtitle:'Sr. Farmer',
        teamTitle:'David Askerph',
    },
    {
        id:2,
        teamImg:'/assets/img/team/team-thumb-02.jpg',
        teamSubtitle:'Farmer',
        teamTitle:'Peter Anderson',
    },
    {
        id:3,
        teamImg:'/assets/img/team/team-thumb-03.jpg',
        teamSubtitle:'Developer',
        teamTitle:'Anzila Yatrian',
    },
    {
        id:4,
        teamImg:'/assets/img/team/team-thumb-04.jpg',
        teamSubtitle:'Designer',
        teamTitle:'Johnson Abert',
    },
    //about team end
    {
        id:5,
        teamImg:'/assets/img/team/team-thumb-05.jpg',
        teamSubtitle:'Farmer Ceo',
        teamTitle:'Mis. Jaqulin',
    },
    {
        id:6,
        teamImg:'/assets/img/team/team-thumb-06.jpg',
        teamSubtitle:'Gardener',
        teamTitle:'Mr. Pongvan',
    },
    {
        id:7,
        teamImg:'/assets/img/team/team-thumb-07.jpg',
        teamSubtitle:'Organic Famer',
        teamTitle:'Eleanor',
    },
    {
        id:8,
        teamImg:'/assets/img/team/team-thumb-08.jpg',
        teamSubtitle:'Designer',
        teamTitle:'Amanda DARKIL',
    },
    {
        id:9,
        teamImg:'/assets/img/team/team-thumb-09.jpg',
        teamSubtitle:'Sr. Famer',
        teamTitle:'Johnson Abert',
    },
    {
        id:10,
        teamImg:'/assets/img/team/team-thumb-10.jpg',
        teamSubtitle:'Farmer',
        teamTitle:'Ella Pippa',
    },
    {
        id:11,
        teamImg:'/assets/img/team/team-thumb-11.jpg',
        teamSubtitle:'Organic Famer',
        teamTitle:'Kelian Anderson',
    },
    {
        id:12,
        teamImg:'/assets/img/team/team-thumb-12.jpg',
        teamSubtitle:'Jr. Famer',
        teamTitle:'William Gabriel',
    }
  ]
  
  export default TeamList;