export const testimonialList = [
    {
      id:1,
      icon: '/assets/img/testimonial/trending-quite.png',
      desc: 'All the generators on the Internet tend to repeat predefined, making this the true generator human made pesticides and fertilizers genetically',
      designation:'Sr. Executive',
      author:'Daniel Branliard',
      starA:'fa-solid fa-star',
      starB:'fa-solid fa-star',
      starC:'fa-solid fa-star',
      starD:'fa-solid fa-star',
      starE:'fa-solid fa-star',
    },
    {
      id:2,
      icon: '/assets/img/testimonial/testimonial-1.png',
      desc: 'All the generators on the Internet tend to repeat predefined, making this the true generator human made pesticides and fertilizers genetically',
      designation:'Sr. Executive',
      author:'Daniel Branliard',
      starA:'fa-solid fa-star',
      starB:'fa-solid fa-star',
      starC:'fa-solid fa-star',
      starD:'fa-solid fa-star',
      starE:'fa-solid fa-star',
    },
    {
      id:3,
      icon: '/assets/img/testimonial/testimonial-2.png',
      desc: 'All the generators on the Internet tend to repeat predefined, making this the true generator human made pesticides and fertilizers genetically',
      designation:'Sr. Executive',
      author:'Andrew  Jaxon',
      starA:'fa-solid fa-star',
      starB:'fa-solid fa-star',
      starC:'fa-solid fa-star',
      starD:'fa-solid fa-star',
      starE:'fa-solid fa-star',
    },
    //test home two end
    {
      id:4,
      icon: '/assets/img/testimonial/testimonial-2.png',
      desc: 'Buying a package usually means you buy two or more services, with each service coming at a discounted price. For example, instead of buying a manicure for combo of the two carrot.',
      designation:'Team Leader, Bdeves',
      author:'Calex White',
      starA:'fa-solid fa-star',
      starB:'fa-solid fa-star',
      starC:'fa-solid fa-star',
      starD:'fa-solid fa-star',
      starE:'fa-solid fa-star',
    },
    {
      id:5,
      icon: '/assets/img/testimonial/testimonial-2.png',
      desc: 'Buying a package usually means you buy two or more services, with each service coming at a discounted price. For example, instead of buying a manicure for combo of the two carrot.',
      designation:'Team Leader, Bdeves',
      author:'Calex White',
      starA:'fa-solid fa-star',
      starB:'fa-solid fa-star',
      starC:'fa-solid fa-star',
      starD:'fa-solid fa-star',
      starE:'fa-solid fa-star',
    },
    //test about end
  ]
  



