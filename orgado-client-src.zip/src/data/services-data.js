const ServicesList = [
    {
        id:1,
        serviceArrowIcon:'/assets/img/step/step-arrow-1.png',
        serviceIcon:'/assets/img/step/step-1.png',
        serviceArrow:true,
        serviceTitle:'Planning',
        serviceDesc:'Consider how some search engines autocorrect for spen.',
    },
    {
        id:2,
        serviceArrowIcon:'/assets/img/step/step-arrow-2.png',
        serviceIcon:'/assets/img/step/step-2.png',
        serviceArrow:true,
        serviceTitle:'Seeding',
        serviceDesc:'Consider how some search engines autocorrect for spen.',
    },
    {
        id:3,
        serviceArrowIcon:'/assets/img/step/step-arrow-1.png',
        serviceIcon:'/assets/img/step/step-1.png',
        serviceArrow:true,
        serviceTitle:'Quality Assure',
        serviceDesc:'Consider how some search engines autocorrect for spen.',
    },
    {
        id:4,
        serviceArrowIcon:'/assets/img/step/step-arrow-1.png',
        serviceIcon:'/assets/img/step/step-3.png',
        serviceArrow:false,
        serviceTitle:'Marketing',
        serviceDesc:'Consider how some search engines autocorrect for spen.',
    },
    //home one service end
  ]
  
  export default ServicesList;