const timelineList = [
    {
        id:1,
        timelineIcon:'/assets/img/why-choose/why-choose-01.png',
        timelineTitle:'100% Organic',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    {
        id:2,
        timelineIcon:'/assets/img/why-choose/why-choose-02.png',
        timelineTitle:'Neat & Clean',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    {
        id:3,
        timelineIcon:'/assets/img/why-choose/why-choose-03.png',
        timelineTitle:'No Preservation',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    {
        id:4,
        timelineIcon:'/assets/img/why-choose/why-choose-04.png',
        timelineTitle:'Export Quality',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    {
        id:5,
        timelineIcon:'/assets/img/why-choose/why-choose-05.png',
        timelineTitle:'Trendy Design',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    {
        id:6,
        timelineIcon:'/assets/img/why-choose/why-choose-06.png',
        timelineTitle:'Fast Delivery',
        timelineDesc:'We show that the seemingly simple process of text realization',
    },
    //home one end
  ]
  
  export default timelineList;